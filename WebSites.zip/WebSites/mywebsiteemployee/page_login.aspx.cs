﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class page_login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        string id = txt_loginid.Text;
        string password = txt_password.Text;
        if(id=="admin@pathfront.com" && password=="paa@123")
        {
            Response.Redirect("~/pageHome.aspx");
        }
        else
        {

            lbl_msg.Text = "Invalid user ID or Password";
        }
    }
}
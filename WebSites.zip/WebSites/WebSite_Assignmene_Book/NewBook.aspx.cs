﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewBook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_add_Click(object sender, EventArgs e)
    {
        Book b = new Book();
        b.BookName = txt_bname.Text;
        b.AuthorName = txt_aname.Text;
        b.BookImageAddress = "~/Images/" + Guid.NewGuid() + ".jpg";
        b_image.SaveAs(Server.MapPath(b.BookImageAddress));
        BookDAL dal = new BookDAL();
        int id = dal.AddBook(b);
    }
}
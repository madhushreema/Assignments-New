﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {
           txt_ordercity .Items.Add(new ListItem("select", ""));
            txt_ordercity.Items.Add(new ListItem("BGL", "BGL "));
            txt_ordercity.Items.Add(new ListItem("Pune", "Pune "));
            txt_ordercity.Items.Add(new ListItem("Chennai", "chaennai"));

            ddl_qty1.Items.Add(new ListItem("select", ""));
            ddl_qty1.Items.Add(new ListItem("1", "1"));
            ddl_qty1.Items.Add(new ListItem("2", "2"));
            ddl_qty1.Items.Add(new ListItem("3", "3"));
            ddl_qty1.Items.Add(new ListItem("4", "4"));

            ddl_productid.Items.Add(new ListItem("select", ""));
            ddl_productid.Items.Add(new ListItem("100", "100"));
            ddl_productid.Items.Add(new ListItem("101", "101"));
            ddl_productid.Items.Add(new ListItem("102", "102"));
        }
    }

    protected void btn_new_order_Click(object sender, EventArgs e)
    {
        placeOrder p = new placeOrder();
        p.OrderID = Convert.ToInt32(OrderID.Text);
        p.CustomerEmailID = emailid.Text;
        p.ProductID = Convert.ToInt32(ddl_productid.Text);
        p.ProductPrice = Convert.ToInt32(price.Text);
        p.ProductQty = Convert.ToInt32(ddl_qty1.Text);
        p.PaymentType = r1.Text;
        p.Address = txt_address.Text;
        OrderDal DAL = new OrderDal();
        int id = DAL.addOrder(p);
        Response.Redirect("~Customer.aspx?code=" + id);

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;//Add
using System.Configuration;//DLL config
using System.Data;//Addd


/// <summary>
/// Summary description for OrderDal
/// </summary>
public class OrderDal
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
     public int  addOrder(placeOrder pc)
    {
        
        try
        {
            SqlCommand sql_com = new SqlCommand("proc_addOrder", con);
            sql_com.Parameters.AddWithValue("@oid", pc.OrderID);
            sql_com.Parameters.AddWithValue("@cid",pc.CustomerEmailID);
            sql_com.Parameters.AddWithValue("@pid", pc.ProductID);
            sql_com.Parameters.AddWithValue("@pprice", pc.ProductPrice);
            sql_com.Parameters.AddWithValue("@pqty", pc.ProductQty);
            sql_com.Parameters.AddWithValue("@city", pc.City);
            sql_com.Parameters.AddWithValue("@ptype", pc.PaymentType);
            sql_com.Parameters.AddWithValue("@address", pc.Address);
            sql_com.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            sql_com.Parameters.Add(retdata);
            con.Open();
            sql_com.ExecuteNonQuery();
            con.Close();
            //SqlCommand com_id = new SqlCommand("select @cid", con);
            int ID = Convert.ToInt32(retdata.Value);
           
            return ID;
        }
          finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

                
            


        }


    }

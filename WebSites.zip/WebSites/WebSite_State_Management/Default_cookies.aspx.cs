﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default_cookies : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_pid_Click(object sender, EventArgs e)
    {

    }

    protected void btn_pid2_Click(object sender, EventArgs e)
    {
        HttpCookie c = new HttpCookie("code", txt_pid.Text);
        c.Expires = DateTime.Now.AddDays(30);
        Response.Cookies.Add(c);

    }

    protected void btn_read_coockie_Click(object sender, EventArgs e)
    {
        HttpCookie c = Request.Cookies["code"];
        lbl_pid2.Text=c.Value;
    }
}
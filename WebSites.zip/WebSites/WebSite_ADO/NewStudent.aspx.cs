﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewStudent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            ddl_city.Items.Add(new ListItem("select", ""));
            ddl_city.Items.Add(new ListItem("BGL", "BGL"));
            ddl_city.Items.Add(new ListItem("Tumkur", "Tumkur"));
            ddl_city.Items.Add(new ListItem("Chennai", "Chennai"));


        }
    }

    protected void btn_add_Click(object sender, EventArgs e)
    {
        Student p = new Student();
        //p.StudentID = Convert.ToInt32(Stdid.Text);
        p.StudentName = txt_name.Text;
        p.StudentCity = ddl_city.Text;
        p.studentImageAddress = "~/Images/" + Guid.NewGuid() + ".jpg";
        txt_image.SaveAs(Server.MapPath(p.studentImageAddress));
        StudentDAL dal = new StudentDAL();
        // DAL = new OrderDal();
        int id = dal.addStudent(p);
    }
}
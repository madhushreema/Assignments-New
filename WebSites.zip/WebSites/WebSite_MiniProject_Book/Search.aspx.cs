﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_show_Click(object sender, EventArgs e)
    {
        BookDAL dal = new BookDAL();
        string key = txt_bid_c1.Text;
        List<Book> list = dal.search(key);
        gv.DataSource = list;
        gv.DataBind();
    }

    protected void gv_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label l = gv.SelectedRow.FindControl("lbl_bid") as Label;
        string id = l.Text;
       // Response.Redirect("~/Details.aspx?id=" + id);

    }
}
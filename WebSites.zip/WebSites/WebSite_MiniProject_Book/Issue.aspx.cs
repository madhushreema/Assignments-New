﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Issue : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void  btn_issue_Click(object sender, EventArgs e)
    {
        Issue1 s = new Issue1();
        s.BookID = Convert.ToInt32(txt_bid.Text);
        s.StudentID = Convert.ToInt32(txt_sid.Text);
        s.issuestatus = txt_status1.Text;
        BookDAL dal = new BookDAL();
        int i = dal.AddTransaction(s);



    }
}
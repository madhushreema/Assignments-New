﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //protected void btn_details_Click(object sender, EventArgs e)
    //{
        
    //}

    //protected void gv_c1_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    Label l = gv_c1.SelectedRow.FindControl("lbl_bookid") as Label;
    //    string id = l.Text;

    //}

    protected void gv_c1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        Label l = gv_c1.SelectedRow.FindControl("lbl_bookid") as Label;
        string id = l.Text;
    }

    protected void btn_show_Click(object sender, EventArgs e)
    {

       // int studentid = Convert.ToInt32(Session["studentid"]);
        BookDAL dal = new BookDAL();
        int id = Convert.ToInt32(txt_bid.Text);
        List<Issue1> list = dal.detailsissue(id);
        gv_c1.DataSource = list;
        gv_c1.DataBind();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DetailBook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void gv_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label l = gv.SelectedRow.FindControl("lbl_bid") as Label;
        string id = l.Text;
    }

    protected void btn_show_Click(object sender, EventArgs e)
    {
        BookDAL dal = new BookDAL();
        int id = Convert.ToInt32(txt_bid_c1.Text);
        List<Book> list = dal.details(id);
        gv.DataSource = list;
        gv.DataBind();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Issue1
{

    public int IssueID { get; set; }
    
    public int BookID { get; set; }
    public int StudentID { get; set; }
   
    public string issuestatus { get; set; }
    public DateTime IssueDate { get; set; }



}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Book
/// </summary>
public class Book
{
    public int BookID { get; set; }
    public string BookName { get; set; }
    public string AuthorName { get; set; }
    public string BookImage { get; set; }
}
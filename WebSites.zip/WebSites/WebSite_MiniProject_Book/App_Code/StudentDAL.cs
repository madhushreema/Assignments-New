﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public class StudentDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public int AddStudent(Student st)
    {
        try
        {
            SqlCommand sql_com = new SqlCommand("proc_AddStudent", con);
            sql_com.Parameters.AddWithValue("@name", st.StudentName);
            sql_com.Parameters.AddWithValue("@email", st.StudentEmailID);
            sql_com.Parameters.AddWithValue("@password", st.StudentPassword);
            sql_com.Parameters.AddWithValue("@image", st.StudentImage);
            sql_com.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            sql_com.Parameters.Add(retdata);
            con.Open();
            sql_com.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(retdata.Value);
            return id;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }




        



   
    public bool login(int id,string password)
    {
        SqlCommand com_sql = new SqlCommand("proc_login", con);

        com_sql.Parameters.AddWithValue("@id", id);
        com_sql.Parameters.AddWithValue("@password", password);
        com_sql.CommandType = CommandType.StoredProcedure;
        SqlParameter retdata = new SqlParameter();
        retdata.Direction = ParameterDirection.ReturnValue;
        //SqlParameter retdata = com_sql.Parameters.Add(retdata);
        com_sql.Parameters.Add(retdata);
        con.Open();
        com_sql.ExecuteNonQuery();
        con.Close();
        int count = Convert.ToInt32(retdata.Value);
        if (count > 0)
        {
            return true;
        }
        else
        {
            return false;
        }



    }
}


